#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/kio_nfs.pot
