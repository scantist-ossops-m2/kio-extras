#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/kio5_thumbnail.pot
