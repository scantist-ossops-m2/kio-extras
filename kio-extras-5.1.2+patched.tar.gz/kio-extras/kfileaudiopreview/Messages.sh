#! /usr/bin/env bash
$XGETTEXT *.h *.cpp -o $podir/kfileaudiopreview5.pot
