#! /bin/sh
#This file has output in separate line each file with a .desktop syntax
#that needs to be translated but has a non .desktop extension
find -name \*.trash -print
