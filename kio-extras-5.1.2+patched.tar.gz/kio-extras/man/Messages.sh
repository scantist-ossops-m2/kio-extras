#! /usr/bin/env bash
$XGETTEXT *.cpp *.h -o $podir/kio_man.pot
