#! /usr/bin/env bash
$XGETTEXT *.cc -o $podir/kio_info.pot
