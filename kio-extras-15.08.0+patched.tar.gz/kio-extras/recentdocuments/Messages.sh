#! /usr/bin/env bash
$XGETTEXT *.cpp *.h -o $podir/kio_recentdocuments.pot
