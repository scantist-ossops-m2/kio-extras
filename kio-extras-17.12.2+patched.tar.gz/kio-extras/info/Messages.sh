#! /usr/bin/env bash
$XGETTEXT *.cc -o $podir/kio5_info.pot
