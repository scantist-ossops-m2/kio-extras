#! /usr/bin/env bash
$XGETTEXT *.cpp *.h -o $podir/kio5_man.pot
