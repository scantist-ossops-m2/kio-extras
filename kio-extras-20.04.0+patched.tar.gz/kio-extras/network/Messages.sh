#! /usr/bin/env bash
$XGETTEXT $(find . -name *.cpp) -o $podir/kio5_network.pot
